create trigger LOG_TRG
  before insert
  on LOG
  for each row
  BEGIN
  IF :new.ID IS NULL THEN
    :new.ID := LOG_ID_SEQ.NEXTVAL;
  END IF;
END;
/

