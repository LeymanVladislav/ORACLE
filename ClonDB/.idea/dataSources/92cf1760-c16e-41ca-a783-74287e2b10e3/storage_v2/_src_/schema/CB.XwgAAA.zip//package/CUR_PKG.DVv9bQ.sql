create PACKAGE CUR_PKG AS

  -- Список URL
  c$URL_LOAD_CUR_LIST_FROM_CB CONSTANT VARCHAR2(1000) := 'http://www.cbr.ru/scripts/XML_valFull.asp';
  c$URL_LOAD_CUR_RATE_FROM_CB CONSTANT VARCHAR2(1000) := 'http://www.cbr.ru/scripts/XML_dynamic.asp';

  -- Формат даты для загрузки курсов ЦБ
  c$DATE_FORMAT_URL CONSTANT VARCHAR2(1000) := 'DD/MM/YYYY'; -- Формат даты передаваемый в URL
  c$DATE_FORMAT_XML CONSTANT VARCHAR2(1000) := 'DD.MM.YYYY'; -- Формат даты в XML ответе

  -- Функция загрузки списка валют с ресурса ЦБ
  FUNCTION LOAD_CUR_LIST_FROM_CB RETURN PLS_INTEGER;

  -- Функция проверки сущестовования курса
  FUNCTION EXISTS_CUR_CB(p$CUR_CB CUR_LIST.CB_CODE%TYPE) RETURN PLS_INTEGER;

  /* Функция загрузки курсов указанной валюты, за указанный период с ресурса ЦБ
  - p$DATE_REQ1 Дата начала периода загрузки
  - p$DATE_REQ1 Дата завершения периода загрузки
  - p$CUR_CB валюта в формате кода ЦБ
  */
  FUNCTION LOAD_CUR_RATE_FROM_CB(p$DATE_REQ1 IN DATE,
                                 p$DATE_REQ2 IN DATE,
                                 p$CUR_CB    IN CUR_LIST.CB_CODE%TYPE) RETURN PLS_INTEGER;

  /* Функция загрузки курсов указанного списка валют, за указанный период с ресурса ЦБ
  - p$DATE_REQ1 Дата начала периода загрузки
  - p$DATE_REQ1 Дата завершения периода загрузки
  - p$CUR_CB_LIST валюта в формате кода ЦБ
  */
  PROCEDURE LOAD_CUR_RATE_FROM_CB(p$DATE_REQ1   IN DATE,
                                 p$DATE_REQ2   IN DATE,
                                 p$CUR_CB_LIST IN VARCHAR2);
END CUR_PKG;
/

