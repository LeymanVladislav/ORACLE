create PACKAGE BODY CUR_PKG AS
  C$NAME CONSTANT VARCHAR2(10) := 'CUR_PKG';

  FUNCTION LOAD_CUR_LIST_FROM_CB RETURN PLS_INTEGER AS
    C$CHILD_NAME CONSTANT VARCHAR2(21) := 'LOAD_CUR_LIST_FROM_CB';

    v_clob$resp CLOB;
    v#Error     PLS_INTEGER := 0;

  BEGIN
    -- Получение списка валют
    v#Error := HTTP_UTL.REQUEST(p$url       => c$URL_LOAD_CUR_LIST_FROM_CB,
                                p$method    => HTTP_UTL.С$GET,
                                p$charset   => HTTP_UTL.С$WIN_1251,
                                p_clob$resp => v_clob$resp);

    -- Загрузка списка в базу
    IF v#Error <> 0 THEN
      RETURN v#Error;
    ELSIF V_CLOB$RESP IS NOT NULL THEN
      MERGE INTO CUR_LIST TBL
      USING (SELECT --RegistryType_STRUCT(extract(t.column_value,'//PNameID/text()').getStringVal(),
              extract(column_value, '//Item/@ID').getStringVal() CB_CODE,
              extract(column_value, '//ParentCode/text()').getStringVal() CB_PARENT_CODE,
              extract(column_value, '//ISO_Num_Code/text()').getStringVal() ISO_NUM_CODE,
              extract(column_value, '//ISO_Char_Code/text()').getStringVal() ISO_CHAR_CODE,
              extract(column_value, '//Name/text()').getStringVal() NAME,
              extract(column_value, '//EngName/text()').getStringVal() ENG_NAME,
              extract(column_value, '//Nominal/text()').getStringVal() NOMINAL
               FROM TABLE(XMLSequence(xmltype(v_clob$resp).extract('//Valuta/Item')))) VW
      ON (TBL.CB_CODE = VW.CB_CODE)
      WHEN MATCHED THEN
        UPDATE
           SET TBL.CB_PARENT_CODE = VW.CB_PARENT_CODE,
               TBL.ISO_NUM_CODE   = VW.ISO_NUM_CODE,
               TBL.ISO_CHAR_CODE  = VW.ISO_CHAR_CODE,
               TBL.NAME           = VW.NAME,
               TBL.ENG_NAME       = VW.ENG_NAME,
               TBL.NOMINAL        = VW.NOMINAL
         WHERE TBL.CB_PARENT_CODE <> VW.CB_PARENT_CODE
            OR TBL.ISO_NUM_CODE <> VW.ISO_NUM_CODE
            OR TBL.ISO_CHAR_CODE <> VW.ISO_CHAR_CODE
            OR TBL.NAME <> VW.NAME
            OR TBL.ENG_NAME <> VW.ENG_NAME
            OR TBL.NOMINAL <> VW.NOMINAL
      WHEN NOT MATCHED THEN
        INSERT (TBL.CB_CODE, TBL.CB_PARENT_CODE, TBL.ISO_NUM_CODE, TBL.ISO_CHAR_CODE, TBL.NAME, TBL.ENG_NAME, TBL.NOMINAL) VALUES (VW.CB_CODE, VW.CB_PARENT_CODE, VW.ISO_NUM_CODE, VW.ISO_CHAR_CODE, VW.NAME, VW.ENG_NAME, VW.NOMINAL);
      dbms_output.put_line(C$NAME || '.' || C$CHILD_NAME || 'count:' || SQL%ROWCOUNT);
      COMMIT;
    ELSE
      RETURN 3;
    END IF;

    RETURN v#Error;

  EXCEPTION
    WHEN OTHERS THEN
      --dbms_output.put_line(C$NAME || '.' || C$CHILD_NAME || 'SQLERRM:' || SQLERRM);
      LOG_PKG.PUT_LOG(C$NAME || '.' || C$CHILD_NAME,SQLCODE,SQLERRM);
      RETURN 1;
  END LOAD_CUR_LIST_FROM_CB;

  FUNCTION EXISTS_CUR_CB(p$CUR_CB CUR_LIST.CB_CODE%TYPE) RETURN PLS_INTEGER AS
    C$CHILD_NAME CONSTANT VARCHAR2(20) := 'EXISTS_CUR_CB';

    v#Count PLS_INTEGER;
  BEGIN
    SELECT COUNT(*) INTO v#Count FROM CUR_LIST WHERE CB_CODE = p$CUR_CB;

    IF v#Count > 0 THEN
      RETURN 0;
    ELSE
      RETURN 1;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      --dbms_output.put_line(C$NAME || '.' || C$CHILD_NAME || 'SQLERRM:' || SQLERRM);
      LOG_PKG.PUT_LOG(C$NAME || '.' || C$CHILD_NAME,SQLCODE,SQLERRM);
      RETURN 1;
  END EXISTS_CUR_CB;

  FUNCTION LOAD_CUR_RATE_FROM_CB(p$DATE_REQ1 IN DATE,
                                 p$DATE_REQ2 IN DATE,
                                 p$CUR_CB    CUR_LIST.CB_CODE%TYPE) RETURN PLS_INTEGER AS
    C$CHILD_NAME CONSTANT VARCHAR2(21) := 'LOAD_CUR_RATE_FROM_CB';

    v_clob$resp CLOB;
    v#Error     PLS_INTEGER := 0;

  BEGIN
    -- Проверка на сущестование курса
    IF EXISTS_CUR_CB(p$CUR_CB) = 1 THEN
      --dbms_output.put_line(C$NAME || '.' || C$CHILD_NAME || ' CUR:' || p$CUR_CB || ' not exists');
      LOG_PKG.PUT_LOG(C$NAME || '.' || C$CHILD_NAME,'1','CUR:' || p$CUR_CB || ' not exists');
      RETURN 1;
    END IF;

    -- Получение курсов указанной валюты
    v#Error := HTTP_UTL.REQUEST(p$url       => c$URL_LOAD_CUR_RATE_FROM_CB || '?' || 'date_req1=' || TO_CHAR(p$DATE_REQ1,
                                                                                                       c$DATE_FORMAT_URL) || '&' || 'date_req2=' || TO_CHAR(p$DATE_REQ2,
                                                                                                                                                      c$DATE_FORMAT_URL) || '&' || 'VAL_NM_RQ=' || p$CUR_CB,
                                p$method    => HTTP_UTL.С$GET,
                                p$charset   => HTTP_UTL.С$WIN_1251,
                                p_clob$resp => v_clob$resp);

    -- Загрузка курсов в базу
    IF v#Error <> 0 THEN
      RETURN v#Error;
    ELSIF V_CLOB$RESP IS NOT NULL THEN
      --dbms_output.put_line(v_clob$resp);
      MERGE INTO CUR_RATES_CB TBL
      USING (SELECT extract(column_value, '//Record/@Date').getStringVal() CUR_DATE,
                    extract(column_value, '//Value/text()').getStringVal() VALUE
               FROM TABLE(XMLSequence(xmltype((v_clob$resp)).extract('//ValCurs/Record')))) VW
      ON (TBL.CB_CODE = p$CUR_CB AND TBL.CUR_DATE = TO_DATE(VW.CUR_DATE, c$DATE_FORMAT_XML))
      WHEN MATCHED THEN
        UPDATE
           SET TBL.VALUE     = VW.VALUE,
               TBL.LOAD_DATE = SYSDATE
         WHERE TBL.VALUE <> VW.VALUE
      WHEN NOT MATCHED THEN
        INSERT
          (TBL.CB_CODE, TBL.CUR_DATE, TBL.VALUE, TBL.LOAD_DATE)
        VALUES
          (p$CUR_CB,
           TO_DATE(VW.CUR_DATE,
                    c$DATE_FORMAT_XML), VW.VALUE, SYSDATE);
      dbms_output.put_line(C$NAME || '.' || C$CHILD_NAME || ' load rows for cur:' || p$CUR_CB || ' count:' || SQL%ROWCOUNT);
      COMMIT;
    ELSE
      RETURN 3;
    END IF;

    RETURN v#Error;

  EXCEPTION
    WHEN OTHERS THEN
      --dbms_output.put_line(C$NAME || '.' || C$CHILD_NAME || 'SQLERRM:' || SQLERRM);
      LOG_PKG.PUT_LOG(C$NAME || '.' || C$CHILD_NAME,SQLCODE,SQLERRM);
      RETURN 1;
  END LOAD_CUR_RATE_FROM_CB;

  PROCEDURE LOAD_CUR_RATE_FROM_CB(p$DATE_REQ1   IN DATE,
                                  p$DATE_REQ2   IN DATE,
                                  p$CUR_CB_LIST IN VARCHAR2) AS

    C$CHILD_NAME CONSTANT VARCHAR2(21) := 'LOAD_CUR_RATE_FROM_CB';

    v#Error  PLS_INTEGER := 0;
    v#i      PLS_INTEGER := 0;
    v$CUR_CB CUR_LIST.CB_CODE%TYPE;
  BEGIN
    LOOP
      v#i      := v#i + 1;
      v$CUR_CB := regexp_substr(p$CUR_CB_LIST,
                                '[^,]+',
                                1,
                                v#i);
      IF v$CUR_CB IS NULL THEN
        EXIT;
      END IF;

      v#Error := CUR_PKG.LOAD_CUR_RATE_FROM_CB(p$DATE_REQ1 => p$DATE_REQ1,
                                               p$DATE_REQ2 => p$DATE_REQ2,
                                               p$CUR_CB    => v$CUR_CB);

      IF v#Error <> 0 THEN
        dbms_output.put_line(C$NAME || '.' || C$CHILD_NAME || ' v#Error:' || v#Error || ' for load rate CUR_CB:' || v$CUR_CB);
      END IF;

    END LOOP;
  END LOAD_CUR_RATE_FROM_CB;

END CUR_PKG;
/

