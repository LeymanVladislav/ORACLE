create PACKAGE LOG_PKG AS

  PROCEDURE PUT_LOG(p$Modul   IN VARCHAR2,
                    p$Code    IN VARCHAR2,
                    p$Message IN VARCHAR2);

END LOG_PKG;
/

