create trigger CUR_RATES_CB_ID_TRG
  before insert
  on CUR_RATES_CB
  for each row
  BEGIN
  IF :new.ID IS NULL THEN
    :new.ID := CUR_RATES_CB_ID_SEQ.NEXTVAL;
  END IF;
END;
/

