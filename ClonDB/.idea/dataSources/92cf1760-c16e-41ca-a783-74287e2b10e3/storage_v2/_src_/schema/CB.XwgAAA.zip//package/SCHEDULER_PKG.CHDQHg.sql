create PACKAGE SCHEDULER_PKG AS

  -- Запрос значения параметра для задани
  FUNCTION GET_PARAM_VAL(p$JOB_NAME IN JOB_PARAMS.JOB_NAME%TYPE,
                         p$PNAME    IN JOB_PARAMS.PNAME%TYPE) RETURN JOB_PARAMS.PVALUE%TYPE;

  -- Процедура для задания загрузки курсов ЦБ
  PROCEDURE LOAD_CUR_RATE_FROM_CB;

END SCHEDULER_PKG;
/

