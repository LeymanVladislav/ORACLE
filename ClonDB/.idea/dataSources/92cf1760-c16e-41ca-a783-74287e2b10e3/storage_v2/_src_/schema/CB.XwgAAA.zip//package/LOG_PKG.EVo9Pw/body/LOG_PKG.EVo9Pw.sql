create PACKAGE BODY LOG_PKG AS

  PROCEDURE PUT_LOG(p$Modul   IN VARCHAR2,
                    p$Code    IN VARCHAR2,
                    p$Message IN VARCHAR2) AS

  BEGIN
    INSERT INTO LOG (DTIME, MODUL, CODE, MESSAGE) VALUES (SYSDATE, p$Modul, p$Code, p$Message);
    COMMIT;
  END PUT_LOG;

END LOG_PKG;
/

