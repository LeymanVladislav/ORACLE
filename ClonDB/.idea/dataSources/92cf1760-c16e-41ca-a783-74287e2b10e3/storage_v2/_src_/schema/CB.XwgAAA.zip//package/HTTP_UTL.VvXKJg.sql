create PACKAGE HTTP_UTL AS

  -- Методы
  С$GET CONSTANT VARCHAR2(5) := 'GET';
  С$POST CONSTANT VARCHAR2(5) := 'POST';

  -- Кодировки
  С$WIN_1251 CONSTANT VARCHAR2(100) := 'windows-1251';

  FUNCTION request(p$url       IN VARCHAR2,
                   p$method    IN VARCHAR2,
                   p$charset   IN VARCHAR2,
                   p_clob$resp IN OUT NOCOPY CLOB) RETURN PLS_INTEGER;
END HTTP_UTL;
/

