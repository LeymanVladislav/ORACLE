create PACKAGE BODY HTTP_UTL AS

  C$NAME CONSTANT VARCHAR2(10) := 'HTTP_UTL';

  FUNCTION REQUEST(p$url       IN VARCHAR2,
                   p$method    IN VARCHAR2,
                   p$charset   IN VARCHAR2,
                   p_clob$resp IN OUT NOCOPY CLOB) RETURN PLS_INTEGER AS

    C$CHILD_NAME CONSTANT VARCHAR2(20) := 'REQUEST';

    v_obj$Req     utl_http.req;
    v_obj$Reqsult utl_http.resp;
    v$Bufer       VARCHAR2(1000);
    v_clob$Resp   CLOB;

    v#Error PLS_INTEGER := 0;

  BEGIN
    v_obj$Req := utl_http.begin_request(p$url,
                                        p$method);

    -- Настройка кодировки windows-1251
    utl_http.set_header(v_obj$Req,
                        'Content-Type',
                        'text/xml; charset=' || p$charset);

    v_obj$Reqsult := utl_http.get_response(v_obj$Req);

    dbms_lob.createtemporary(v_clob$Resp,
                             TRUE);
    BEGIN
      LOOP
        utl_http.read_text(v_obj$Reqsult,
                           v$Bufer,
                           1000);
        dbms_lob.append(v_clob$Resp,
                        v$Bufer);
      END LOOP;
    EXCEPTION
      WHEN utl_http.end_of_body THEN
        utl_http.end_response(v_obj$Reqsult);
    END;

    p_clob$resp := v_clob$resp;
    dbms_lob.freetemporary(v_clob$resp);

    RETURN v#Error;
  EXCEPTION
    WHEN OTHERS THEN
      LOG_PKG.PUT_LOG(C$NAME || '.' || C$CHILD_NAME,SQLCODE,SQLERRM);
      RETURN 1;
  END REQUEST;

END HTTP_UTL;
/

